const express = require('express');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const app = express();
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const users = new Map(); // username -> { salt, hash }

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64);
}

// Register
app.post('/register', (req, res) => {
  const { username, password } = req.body || {};
  if (
    typeof username !== 'string' || username.trim() === '' ||
    typeof password !== 'string' || password.length < 6
  ) {
    return res.status(400).json({ error: 'Invalid input' });
  }
  const name = username.trim();
  if (users.has(name)) {
    return res.status(409).json({ error: 'Username already exists' });
  }
  const salt = crypto.randomBytes(16);
  users.set(name, { salt, hash: hashPassword(password, salt) });
  res.status(201).json({ message: 'User registered' });
});

// Login
app.post('/login', (req, res) => {
  const { username, password } = req.body || {};
  const user = typeof username === 'string' ? users.get(username.trim()) : undefined;
  if (!user || typeof password !== 'string') {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const attempt = hashPassword(password, user.salt);
  if (!crypto.timingSafeEqual(attempt, user.hash)) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }
  const token = jwt.sign({ username: username.trim() }, JWT_SECRET, {
    algorithm: 'HS256',
    expiresIn: '1h',
  });
  res.status(200).json({ token });
});

// Auth middleware
function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  const match = typeof header === 'string' && header.match(/^Bearer\s+(\S+)$/i);
  if (!match) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const payload = jwt.verify(match[1], JWT_SECRET, { algorithms: ['HS256'] });
    req.user = payload;
    next();
  } catch (e) {
    // malformed, bad signature or expired
    res.status(401).json({ error: 'Unauthorized' });
  }
}

// Protected profile
app.get('/profile', requireAuth, (req, res) => {
  res.status(200).json({ username: req.user.username });
});

// Malformed JSON body -> 400
app.use((err, req, res, next) => {
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Invalid input' });
  }
  next(err);
});

module.exports = app;

if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`Listening on ${PORT}`));
}
