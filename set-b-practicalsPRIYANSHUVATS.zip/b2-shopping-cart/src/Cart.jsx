import { useState } from 'react';

// Discount rule: 10% off when the cart total reaches 1000.00 or more.
// (The task does not state the rule; change these two constants if yours differs.)
const DISCOUNT_THRESHOLD_CENTS = 100000;
const DISCOUNT_RATE = 0.1;

const fmt = (cents) => (cents / 100).toFixed(2);

export default function Cart({ products = [] }) {
  const [cart, setCart] = useState([]); // [{ id, qty }] in the order added

  const add = (id) =>
    setCart((c) =>
      c.some((l) => l.id === id)
        ? c.map((l) => (l.id === id ? { ...l, qty: l.qty + 1 } : l))
        : [...c, { id, qty: 1 }]
    );

  const inc = (id) =>
    setCart((c) => c.map((l) => (l.id === id ? { ...l, qty: l.qty + 1 } : l)));

  // Quantity never drops below 1; use the remove button to delete a line.
  const dec = (id) =>
    setCart((c) =>
      c.map((l) => (l.id === id && l.qty > 1 ? { ...l, qty: l.qty - 1 } : l))
    );

  const remove = (id) => setCart((c) => c.filter((l) => l.id !== id));

  const lines = cart
    .map((l) => ({ ...l, product: products.find((p) => p.id === l.id) }))
    .filter((l) => l.product);

  const totalCents = lines.reduce(
    (sum, l) => sum + Math.round(l.product.price * 100) * l.qty,
    0
  );
  const hasDiscount = totalCents >= DISCOUNT_THRESHOLD_CENTS;
  const discountCents = hasDiscount ? Math.round(totalCents * DISCOUNT_RATE) : 0;
  const grandCents = totalCents - discountCents;

  return (
    <div>
      <h2>Products</h2>
      <ul>
        {products.map((p) => (
          <li key={p.id}>
            {p.name} - {Number(p.price).toFixed(2)}{' '}
            <button data-testid={`add-${p.id}`} onClick={() => add(p.id)}>
              Add to cart
            </button>
          </li>
        ))}
      </ul>

      <h2>Cart</h2>
      {lines.length === 0 ? (
        <p data-testid="cart-empty">Cart is empty</p>
      ) : (
        <ul>
          {lines.map(({ id, qty, product }) => (
            <li key={id}>
              {product.name} - {Number(product.price).toFixed(2)}{' '}
              <button data-testid={`dec-${id}`} onClick={() => dec(id)}>-</button>
              <span data-testid={`qty-${id}`}>{qty}</span>
              <button data-testid={`inc-${id}`} onClick={() => inc(id)}>+</button>{' '}
              <button data-testid={`remove-${id}`} onClick={() => remove(id)}>
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}

      <p data-testid="total">{`Total: ${fmt(totalCents)}`}</p>
      {hasDiscount && (
        <>
          <p data-testid="discount">{`Discount: ${fmt(discountCents)}`}</p>
          <p data-testid="grand-total">{`Grand Total: ${fmt(grandCents)}`}</p>
        </>
      )}
    </div>
  );
}
